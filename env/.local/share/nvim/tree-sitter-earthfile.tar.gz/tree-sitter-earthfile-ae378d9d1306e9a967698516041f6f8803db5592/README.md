# tree-sitter-earthfile

[tree-sitter](https://tree-sitter.github.io/) grammar for [Earthfile](https://docs.earthly.dev/docs/earthfile).

![Screenshot of yage Earthfile in neovim](screenshot.jpg)

## License

`tree-sitter-earthfile` is distributed under the terms of the MIT license.

See [LICENSE](LICENSE) for details.
