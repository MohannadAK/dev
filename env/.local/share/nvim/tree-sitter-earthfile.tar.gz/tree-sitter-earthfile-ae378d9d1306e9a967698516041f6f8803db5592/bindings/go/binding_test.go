package tree_sitter_earthfile_test

import (
	"testing"

	tree_sitter "github.com/smacker/go-tree-sitter"
	"github.com/tree-sitter/tree-sitter-earthfile"
)

func TestCanLoadGrammar(t *testing.T) {
	language := tree_sitter.NewLanguage(tree_sitter_earthfile.Language())
	if language == nil {
		t.Errorf("Error loading Earthfile grammar")
	}
}
